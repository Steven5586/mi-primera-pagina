
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];


document.addEventListener('DOMContentLoaded', function() {
    actualizarContador();
});


function agregarProducto(nombre, precio) {
    const producto = {
        nombre: nombre,
        precio: precio,
        id: Date.now() 
    };
    
    carrito.push(producto);
    guardarCarrito();
    actualizarContador();
    
  
    mostrarNotificacion(`${nombre} agregado al carrito`);
}


function guardarCarrito() {
    localStorage.setItem("carrito", JSON.stringify(carrito));
}


function actualizarContador() {
    const contador = document.getElementById("contador-carrito");
    if (contador) {
        contador.textContent = carrito.length;
    }
}


function actualizarCarrito() {
    const listaCarrito = document.getElementById("lista-carrito");
    const carritoVacio = document.getElementById("carrito-vacio");
    const carritoContenido = document.getElementById("carrito-contenido");
    const totalCarrito = document.getElementById("total-carrito");
    
    if (!listaCarrito) return;
    

    listaCarrito.innerHTML = "";
    
    if (carrito.length === 0) {
     
        if (carritoVacio) carritoVacio.style.display = "block";
        if (carritoContenido) carritoContenido.style.display = "none";
    } else {
      
        if (carritoVacio) carritoVacio.style.display = "none";
        if (carritoContenido) carritoContenido.style.display = "block";
        
        let total = 0;
        
        carrito.forEach((producto, index) => {
            total += producto.precio;
            
            const li = document.createElement("li");
            li.innerHTML = `
                <span>${producto.nombre}</span>
                <span>$${producto.precio.toLocaleString()} COP</span>
                <button class="btn-eliminar" onclick="eliminarProducto(${index})">Eliminar</button>
            `;
            listaCarrito.appendChild(li);
        });
        

        if (totalCarrito) {
            totalCarrito.textContent = `$${total.toLocaleString()} COP`;
        }
    }
    
    actualizarContador();
}

function eliminarProducto(index) {
    const productoEliminado = carrito[index].nombre;
    carrito.splice(index, 1);
    guardarCarrito();
    actualizarCarrito();
    
    // Cole esa vaina que 
    mostrarNotificacion(`${productoEliminado} eliminado del carrito`);
}


function vaciarCarrito() {
    if (carrito.length === 0) {
        mostrarNotificacion("El carrito ya está vacío");
        return;
    }
    
    if (confirm("¿Estás seguro de que quieres vaciar el carrito?")) {
        carrito = [];
        guardarCarrito();
        actualizarCarrito();
        mostrarNotificacion("Carrito vaciado correctamente");
    }
}


function finalizarCompra() {
    if (carrito.length === 0) {
        mostrarNotificacion("El carrito está vacío");
        return;
    }
    
  
    let total = 0;
    carrito.forEach(p => total += p.precio);
    
    alert(`¡Gracias por tu compra!\n\nTotal: $${total.toLocaleString()} COP\n\nRecibirás un correo de confirmación.`);
    

    carrito = [];
    guardarCarrito();
    actualizarCarrito();
    
  
    window.location.href = "index.html";
}


function mostrarNotificacion(mensaje) {

    const notificacion = document.createElement("div");
    notificacion.className = "notificacion";
    notificacion.textContent = mensaje;
    

    notificacion.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #174d4d;
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 10000;
        animation: aparecer 0.3s ease;
    `;
    
    document.body.appendChild(notificacion);
    

    setTimeout(() => {
        notificacion.style.animation = "desaparecer 0.3s ease";
        setTimeout(() => {
            document.body.removeChild(notificacion);
        }, 300);
    }, 3000);
}


function toggleMenu() {
    const navMenu = document.querySelector(".nav-menu");
    if (navMenu) {
        navMenu.classList.toggle("active");
    }
}


function irAlCarrito() {
    window.location.href = "carrito.html";
}